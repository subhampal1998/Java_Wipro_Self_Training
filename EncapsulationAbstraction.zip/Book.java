package EncapsulationAbstraction;

public class Book {
	 String name;
	 static Author author;
	 double price;
	 int qtyInStock;
	public Book(String n, double p, int q)
	{
		name=n;
		author=new Author("Subham Pal","subhamp27@gmail.com",'M');
		price=p;
		qtyInStock=q;
	}

	public static void main(String[] args) {
		Book b1=new Book("Computer Applications",234.34,12);
		System.out.println("Name of Book: "+b1.name);
		System.out.println("Price of Book: "+b1.price);
		System.out.println("Quantity in stock: "+b1.qtyInStock);
		System.out.println("Name of Author: "+author.name);
		System.out.println("Email of Author: "+author.email);
		System.out.println("Gender of Author: "+author.gender);
		
		

	}

}
