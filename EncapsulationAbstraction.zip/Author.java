package EncapsulationAbstraction;

public class Author {
	String name;
	String email;
	char gender;
	public Author(String n, String e, char g)
	{
		name=n;
		email=e;
		gender=g;
	}

}
