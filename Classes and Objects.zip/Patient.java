package classesobjects;

public class Patient {
	String patientName;
	double height;
	double weight;
	public Patient()
	{
		patientName="Subham Pal";
		height=1.7;
		weight=65;
	}
	public double computeBMI()
	{
		double x=weight/(height*height);
		return x;
	}
			

	public static void main(String[] args) {
		Patient p1=new Patient();
		double x=p1.computeBMI();
		System.out.println(x);

	}

}
