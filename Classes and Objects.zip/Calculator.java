package classesobjects;

public class Calculator {

	public static void main(String[] args) {
		Calculator cal=new Calculator();
		int x=cal.powerInt(12,2);
		double y=cal.powerDouble(14.2,3);
		System.out.println(x);
		System.out.println(y);
		

	}
	public static int powerInt(int num1, int num2)
	{
		int res=(int)Math.pow(num1,num2);
		return res;
	}
	public static double powerDouble(double num1, int num2)
	{
		double res=Math.pow(num1,num2);
		return res;
	}
}
