package classesobjects;

public class Box {
	int height;
	int width;
	int depth;
	public Box(int h, int w, int d)
	{
		height=h;
		width=w;
		depth=d;
	}
	public int volume()
	{
		return height*width*depth;
	}

	public static void main(String[] args) {
		Box b1=new Box(23,34,44);
		int n=b1.volume();
		System.out.println(n);
	}

}
