public class Employee
    {
        String firstname;
        String lastname;
        String mobno;
        String email;
        String address;
        public Employee(String firstname,String lastname,String mobno,String email,String address)
        {
            this.firstname=firstname;
            this.lastname=lastname;
            this.mobno=mobno;
            this.email=email;
            this.address=address;
        }
    }