package Inheritance;

public class Person {
	String name;
	Person(String a)
	{
		name=a;
	}

}
