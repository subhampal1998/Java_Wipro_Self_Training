package Inheritance;

public class Bird extends Animal {
	void fly()
	{
	}

}
class Call
{
	public static void main(String[] args)
	{
		Animal A=new Animal();
		A.eat();
		A.sleep();
		Bird B=new Bird();
		B.eat();
		B.sleep();
		B.fly();
	}
}