package SchoolApplication;

public class Person {
	String name;
	String DOB;
	Person(String n, String dob)
	{
		name=n;
		DOB=dob;
	}

}
 class Teacher extends Person {
	 double salary;
	 String sub;
	 Teacher(String n, String dob)
	 {
		 super(n,dob);
	 }
	 void getSalary(double s)
	 {
		 salary=s;
	 }
	 void setSubject(String s)
	 {
		 sub=s;
	 }
	 
}
class Student extends Person{
	int StdId;
	Student(String n, String dob)
	 {
		 super(n,dob);
	 }
	void getId(int id)
	{
		StdId=id;
	}
}
class CollegeStudent extends Student{
	String clgname;
	String year;
	CollegeStudent(String n, String dob)
	 {
		 super(n,dob);
	 }
	void getCollegeName(String cn)
	{
		clgname=cn;
	}
	void setYear(String y)
	{
		year=y;
	}
}
class Test
{
	public static void main(String []args)
	{
		Teacher T1=new Teacher("Subham Pal","11.02.1998");
		T1.getSalary(24789.98);
		T1.setSubject("Physics");
		Student S1=new Student("Subham Pal","11.02.1998");
		S1.getId(1234);
		CollegeStudent C1=new CollegeStudent("Subham Pal","11.02.1998");
		C1.getCollegeName("University Institute Of Technology");
		C1.setYear("fourth");
	}
}