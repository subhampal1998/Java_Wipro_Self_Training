package Inheritance;

public class Employee extends Person{
	double annualsalary;
	int year;
	String NIA;
	Employee(String name)
	{
		super(name);
	}
	void getAnnualSalary(double as)
	{
		annualsalary=as;
	}
	void setYear(int y)
	{
		year=y;
	}
	void getNationalSecurityNumber(String nia)
	{
		NIA=nia;
	}
	

}
class TestEmployee
{
	public static void main(String []args)
	{
		Employee E1=new Employee("Subham Pal");
		E1.getAnnualSalary(34567.23);
		E1.setYear(2019);
		E1.getNationalSecurityNumber("QQ123456C");
		
	}
}
