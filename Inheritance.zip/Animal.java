package Inheritance;

public class Animal {
	void eat()
	{
	}
	void sleep()
	{
	}
}


