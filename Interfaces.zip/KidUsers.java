
public class KidUsers implements LibraryUser {
	int age;
	String bookType;
	KidUsers(int a,String bt)
	{
		age=a;
		bookType=bt;
	}
	
	public void registerAccount() {
		if(age<12)
			System.out.println("You have sucessfully registered under a kids account");
		if(age>12)
			System.out.println("Sorry, Age must be less than 12 to register as a kid");

	}

	
	public void requestBook() {
		if(bookType.equals("Kids"))
			System.out.println("Book issused successfully, please return the book within 10 days");
		else
			System.out.println("Oops, you are allowed to take only kids books");

	}

}
