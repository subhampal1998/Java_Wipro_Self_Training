public class AdultUser implements LibraryUser {
	int age;
	String bookType;
	AdultUser(int a,String bt)
	{
		age=a;
		bookType=bt;
	}
	
	public void registerAccount() {
		if(age>12)
			System.out.println("You have sucessfully registered under an Adult Account");
		if(age<12)
			System.out.println("Sorry, Age must be greater than 12 to register as an adult");

	}

	
	public void requestBook() {
		if(bookType.equals("Fiction"))
			System.out.println("Book issused successfully, please return the book within 7 days");
		else
			System.out.println("Oops, you are allowed to take only adult fiction books");

	}

}
