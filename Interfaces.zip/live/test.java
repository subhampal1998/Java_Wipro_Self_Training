package live;
import music.*;
import music.string.*;
import music.wind.*;
public class test {

	public static void main(String[] args) {
		Veena v=new Veena();
		Saxophone s=new Saxophone();
		v.play();
		s.play();
		Playable pv=v;
		Playable ps=s;
		pv.play();
		ps.play();
	}

}
