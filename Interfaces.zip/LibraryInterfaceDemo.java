
public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		KidUsers ku=new KidUsers(5,"Kids");
		AdultUser au=new AdultUser(34,"Fiction");
		ku.registerAccount();
		ku.requestBook();
		au.registerAccount();
		au.requestBook();

	}

}
