package FloCon;

public class FloCon10 {

	public static void main(String[] args) {
		for(int i=1;i<=10;i++)
			System.out.print(i+"  ");

	}	

}
