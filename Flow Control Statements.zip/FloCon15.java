package FloCon;

public class FloCon15 {

	public static void main(String[] args) {
		int n=Integer.parseInt(args[0]);
		int sum=0;
		for(int t=n;t>0;t=t/10)
		{
			int r=t%10;
			sum=sum+r;
		}
		System.out.println(sum);
				

	}

}
