package FloCon;

public class FloCon18 {

	public static void main(String[] args) {
		int n=Integer.parseInt(args[0]);
		int rev=0;
		int t=n;
		while(t>0)
		{
			int r=t%10;
			rev=(rev*10)+r;
			t=t/10;
		}
		if(n==rev)
			System.out.println(n+" is a palindrome");
		else
			System.out.println(n+" is not a palindrome");

	}

}
