package FloCon;

public class FloCon7 {

	public static void main(String[] args) {
		char x=args[0].charAt(0);
		if(x>='A'&&x<='Z')
			x=(char)(32+(int)x);
		else
			x=(char)((int)x-32);
		System.out.println(x);
			
		

	}

}
