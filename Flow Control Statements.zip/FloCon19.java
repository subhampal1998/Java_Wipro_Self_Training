package FloCon;

public class FloCon19 {

	public static void main(String[] args) {
		int c=1;
		int num=1;
		while(c<=5)
		{
			if(num%2==0&&num%3==0&&num%5==0)
			{
				System.out.println(num);
				c++;
			}
			num++;
		}
	}

}
