package FloCon;
import java.io.*;
public class FloCon14 {

	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please enter an integer number");
		int n=Integer.parseInt(r.readLine());
		if(n==0||n==1)
			System.out.println(n+" is neither prime nor composite");
		else 
		{
			int f=0;
			for(int i=2;i<n/2;i++)
			{
				if(n%i==0)
				{
					System.out.println(n+" is not a prime number");
					f=1;
					break;
				}
			}
				if(f==0)
					System.out.println(n+" is a prime number");
		}
		
		
	}

}
