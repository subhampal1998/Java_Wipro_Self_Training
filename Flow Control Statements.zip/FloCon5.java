package FloCon;

public class FloCon5 {

	public static void main(String[] args) {
		if(args[0].charAt(0)>='A'&&args[0].charAt(0)<='Z')
			System.out.println("Alphabet");
		else if(args[0].charAt(0)>='a'&&args[0].charAt(0)<='z')
			System.out.println("Alphabet");
		else if(args[0].charAt(0)>='0'&&args[0].charAt(0)<='9')
			System.out.println("Digit");
		else
			System.out.println("Special Character");

	}

}
