package FloCon;
import java.io.*;
public class FloCon16 {

	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please enter an integer number");
		int n=Integer.parseInt(r.readLine());
		for(int i=1;i<=n;i++)
		{
			int j=1;
			while(j<=i)
			{
				System.out.print("*");
				j++;
			}
			System.out.println();
			
		}
	}

}
