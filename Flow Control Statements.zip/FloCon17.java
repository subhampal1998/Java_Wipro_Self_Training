package FloCon;

public class FloCon17 {

	public static void main(String[] args) {
		int n=Integer.parseInt(args[0]);
		int rev=0;
		while(n>0)
		{
			int r=n%10;
			rev=r+(rev*10);
			n=n/10;
		}
System.out.println(rev);
	}

}
