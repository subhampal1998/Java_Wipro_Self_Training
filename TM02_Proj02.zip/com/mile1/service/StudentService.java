package com.mile1.service;
import com.mile1.bean.*;
public class StudentService {
	public int findNumberOfNullMarks(Student data[])
	{
		int count=0;
		int l=data.length;
		for(int i=0;i<l;i++)
		{
			
			if(data[i].marks.length==0&&data[i]!=null)
				count++;
			
			
		}
		return count;
	}
	public int findNumberOfNullNames(Student data[])
	{
		int count=0;
		int l=data.length;
		for(int i=0;i<l;i++)
		{
			
			if(data[i].name.equals("")&&data[i]!=null)
				count++;
			
			
		}
		return count;
	}
	public int findNumberOfNullObject(Student data[])
	{
		int count=0;
		int l=data.length;
		for(int i=0;i<l;i++)
		{
			if(data[i]==null)
				count++;
		}
		return count;
	}
}
