package com.mile1.service;
import com.mile1.bean.*;
import com.mile1.exception.*;
public class StudentReport {
	public String findGrade(Student studentObject)
	{
		for(int i=0;i<3;i++)
		{
			if(studentObject.marks[i]<35)
				return "F";
		}
			int sum=studentObject.marks[0]+studentObject.marks[1]+studentObject.marks[2];
				if(sum<=150)
					return "D";
				else if(sum>150&&sum<=200)
					return "C";
				else if(sum>200&&sum<=250)
					return "B";
				else if(sum>250&&sum<=300)
					return "A";
			return null;
			
	}
	public String validate(Student studentObject)throws NullStudentException, NullNameException, NullMarksArrayException
	{
		int f=0;
		if(studentObject==null)
		{
			f=1;
			throw new NullStudentException();
		}
		else
		{
			if(studentObject.name==null)
			{   f=1;
				throw new NullNameException();
			}
			if(studentObject.marks==null)
			{	f=1;
				throw new NullMarksArrayException();
			}
		}
		if(f==0)
			findGrade(studentObject);
		return null;
	}
}
