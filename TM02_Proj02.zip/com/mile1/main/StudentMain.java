package com.mile1.main;
import com.mile1.bean.*;
import com.mile1.exception.NullMarksArrayException;
import com.mile1.exception.NullNameException;
import com.mile1.exception.NullStudentException;
import com.mile1.service.*;
public class StudentMain {
	static Student data[]=new Student[4];
	static
	{
		data[0]=new Student("Sekar",new int[] {35,35,35});
		data[1]=new Student(null,new int[] {11,22,33});
		data[2]=null;
		data[3]=new Student("Manoj",null);
	}
	public static void main(String[] args)throws NullStudentException, NullNameException, NullMarksArrayException {
		
			StudentReport sr=new StudentReport();
			String x=null;
			for(int i=0;i<=3;i++)
			{
			try
			{
				x=sr.validate(data[i]);
			}
			catch(NullNameException e)
			{
				x="NullNameException occured";
			}
			catch(NullMarksArrayException e)
			{
				x="NullMarksArrayException occured";
			}
			catch(NullStudentException e)
			{
				x="NullStudentException occured";
			}
			
			System.out.println("GRADE="+x);
			
			}
			StudentService ss=new StudentService();
			//System.out.println("Number of Objects with Marks Array as null "+ss.findNumberOfNullMarks(data));
			System.out.println("Number of Objects with Name as null "+ss.findNumberOfNullNames(data));
			System.out.println("Number of Objects that are entirely null "+ss.findNumberOfNullObject(data));
	}
}
			
		
	


