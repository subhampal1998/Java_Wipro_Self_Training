package com.mile1.exception;

public class NullMarksArrayException extends Exception {
	public String toString()
	{
		return "NullMarksArrayException Occured"; 
	}
	
}
