
public class TestFruit {

	public static void main(String[] args) {
		Apple a=new Apple();
		a.eat();
		System.out.println(a.name);
		System.out.println(a.taste);
		Orange o=new Orange();
		o.eat();
		System.out.println(o.name);
		System.out.println(o.taste);

	}

}
