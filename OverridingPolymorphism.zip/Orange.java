
public class Orange extends Fruit {
	void eat()
	{
		name="Orange";
		taste="Sour";
	}

}
