
public class Apple extends Fruit {
	void eat()
	{
		name="Apple";
		taste="Sweet,Sour";
	}

}
