
public class Fruit {
	String name;
	String taste;
	int size;
	void eat()
	{
		name="";
		taste="";
	}

}
