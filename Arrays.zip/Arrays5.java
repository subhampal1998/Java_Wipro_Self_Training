package arrJav;

public class Arrays5 {

	public static void main(String[] args) {
		int len=args.length;
		int arr[]=new int[len];
		for(int i=0;i<len;i++)
			arr[i]=Integer.parseInt(args[i]);
		for(int i=0;i<len-1;i++)
		{
			for(int j=0;j<len-1-i;j++)
			{
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		System.out.println("The largest 2 numbers are "+arr[len-1]+","+arr[len-2]);
		System.out.println("The smallest 2 numbers are "+arr[0]+","+arr[1]);
	}
}