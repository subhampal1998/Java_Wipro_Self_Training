package arrJav;
import java.io.*;
public class Arrays3 {

	public static void main(String[] args)throws IOException {
		
			BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter number to be searched");
			int n=Integer.parseInt(r.readLine());
			int f=0;
			int len=args.length;
			int arr[]=new int[len];
			for(int i=0;i<len;i++)
			{
				arr[i]=Integer.parseInt(args[i]);
				if(arr[i]==n)
				{
					System.out.println(i+1);
					f=1;
				}
			}
				if(f==0)
					System.out.println(-1);
			
			
		}

	}



