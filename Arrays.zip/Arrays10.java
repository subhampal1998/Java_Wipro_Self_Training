package arrJav;
import java.io.*;
public class Arrays10 {

	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		int arr[][]=new int[3][3];
		System.out.println("Please enter 9 integer numbers");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				arr[i][j]=Integer.parseInt(r.readLine());
		}
		int max=arr[0][0];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(arr[i][j]>max)
					max=arr[i][j];
			}
				
		}
		System.out.println("The given array is :");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				System.out.print(arr[i][j]+" ");
		System.out.println();
		}
System.out.println("The biggest number in the given array is "+max);
	}

}
