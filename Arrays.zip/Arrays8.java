package arrJav;

public class Arrays8 {

	public static void main(String[] args) {
		int len=args.length;
		int sum=0;
		int arr[]=new int[len];
		for(int i=0;i<len;i++)
			arr[i]=Integer.parseInt(args[i]);
		for(int i=0;i<len;i++)
		{
			if(arr[i]==6)
			{
				for(int j=i;j<len;j++)
				{
					if(arr[j]==7)
						i=j+1;
				}
			}
			sum=sum+arr[i];
		}
		System.out.print(sum);

	}

}
