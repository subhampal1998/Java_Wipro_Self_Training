package arrJav;

public class Arrays2 {

	public static void main(String[] args) {
		int len=args.length;
		int arr[]=new int[len];
		for(int i=0;i<len;i++)
			arr[i]=Integer.parseInt(args[i]);
		int max=arr[0];
		int min=arr[0];
		int posmax=0;
		int posmin=0;
		for(int i=0;i<len;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
				posmax=i;
			}
			if(min>arr[i])
			{
				min=arr[i];
				posmin=i;
			}
		}
		System.out.println("The maximum value is "+max+" at postion "+posmax);
		System.out.println("The minimum value is "+min+" at postion "+posmin);

	}

}
