package arrJav;

public class Arrays4 {

	public static void main(String[] args) {
		int len=args.length;
		int arr[]=new int[len];
		for(int i=0;i<len;i++)
			arr[i]=Integer.parseInt(args[i]);
		for(int i=0;i<len;i++)
			System.out.print((char)arr[i]+" ");

	}

}
