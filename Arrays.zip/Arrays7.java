package arrJav;

public class Arrays7 {

	public static void main(String[] args) {
		int len=args.length;
		int arr[]=new int[len];
		for(int i=0;i<len;i++)
			arr[i]=Integer.parseInt(args[i]);
		for(int i=0;i<len-1;i++)
		{
			for(int j=i+1;j<len;j++)
			{
				if(arr[i]==arr[j])
				{
					for(int k=j;k<len-1;k++)
						arr[k]=arr[k+1];
					len--;
				}
			}
		}
		for(int i=0;i<len;i++)
			System.out.print(arr[i]+" ");

	}

}
