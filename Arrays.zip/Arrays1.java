package arrJav;

public class Arrays1 {

	public static void main(String[] args) {
		int len=args.length;
		int arr[]=new int[len];
		double sum=0.0;
		double avg=0.0;
		for(int i=0;i<len;i++)
		{
			arr[i]=Integer.parseInt(args[i]);
			sum=sum+arr[i];
		}
		avg=sum/len;
		System.out.println("The sum is "+sum);
		System.out.println("The average is "+avg);

}
}
