
public class TestInstrument {

	public static void main(String[] args) {
		Instrument arr[]=new Instrument[10];
		arr[0]=new Piano();
		arr[2]=new Flute();
		arr[7]=new Guitar();
		for(int i=0;i<10;i++)
		{
			if(arr[i] instanceof Piano)
			{
				System.out.println("Instance of Piano at "+i);
				arr[i].play();
			}
			if(arr[i] instanceof Flute)
			{
				System.out.println("Instance of Flute at "+i);
				arr[i].play();
			}
			if(arr[i] instanceof Guitar)
			{
				System.out.println("Instance of Guitar at "+i);
				arr[i].play();
			}
				
		}
				

	}

}
