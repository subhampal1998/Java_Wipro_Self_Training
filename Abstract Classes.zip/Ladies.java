
public class Ladies extends Compartment {
	public String notice()
	{
		return "Ladies";
	}
}
