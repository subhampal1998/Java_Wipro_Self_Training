
public class TestBank {

	public static void main(String[] args) {
		 ICICIBank i=new ICICIBank();
		 KotMBank k=new KotMBank();
		 GeneralBank g=new KotMBank();
		 GeneralBank g1=new ICICIBank();
		 System.out.println(i.getSavingsInterestRate());
		 System.out.println(i.getFixedDepositInterestRate());
		 System.out.println(k.getSavingsInterestRate());
		 System.out.println(k.getFixedDepositInterestRate());
		 System.out.println(g.getSavingsInterestRate());
		 System.out.println(g.getFixedDepositInterestRate());
		 System.out.println(g1.getSavingsInterestRate());
		 System.out.println(g1.getFixedDepositInterestRate());

	}

}
