
public class FirstClass extends Compartment {
	public String notice()
	{
		return "FirstClass";
	}
}
