import java.util.*;
public class List7 {

	public static void main(String[] args) {
		Vector<Employee> v1=new Vector<Employee>();
		Employee e=new Employee();
		e.empId=1234;
		e.empName="Subham Pal";
		e.email="subhamp27@gmail.com";
		e.gender="Male";
		e.salary=50000.0f;
		v1.add(e);
		e.empId=12345;
		e.empName="Aishik Dutta";
		e.email="aishik27@gmail.com";
		e.gender="Male";
		e.salary=40000.0f;
		v1.add(e);
		Iterator<Employee> i=v1.iterator();
		while(i.hasNext())
		{
			i.next();
		}
		Enumeration<Employee> e1 = Collections.enumeration(v1); 
		 while (e1.hasMoreElements()) 
              e1.nextElement();
	
		
	}

}
