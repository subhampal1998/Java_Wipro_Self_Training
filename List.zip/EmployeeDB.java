import java.util.*;
import java.io.*;
public class EmployeeDB {
	static ArrayList<Employee> list=new ArrayList<Employee>();
	static boolean addEmployee(Employee e)
	{
		list.add(e);
		return true;
	}
	static boolean deleteEmployee(int empid)
	{
		for(int i=0;i<list.size();i++)
		{
			Employee e=list.get(i);
			if(e.empId==empid)
			{
				list.remove(i);
				return true;
			}
		}
		return false;
	}
	static String ShowPaySlip(int empid)
	{
		for(int i=0;i<list.size();i++)
		{
			Employee e=list.get(i);
			if(e.empId==empid)
			{
				e.GetEmployeeDetails();
			}
		}
		return null;
	}
	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("1.Add Employee");
		System.out.println("2.Delete Employee");
		System.out.println("3.Show employee details");
		System.out.println("4.Exit");
		int n=Integer.parseInt(r.readLine());
		switch(n)
		{
		case 1:
		{
			Employee e=new Employee();
			System.out.println("Enter Employee ID");
			e.empId=Integer.parseInt(r.readLine());
			System.out.println("Enter Employee name");
			e.empName=r.readLine();
			System.out.println("Enter Email");
			e.email=r.readLine();
			System.out.println("Enter gender");
			e.gender=r.readLine();
			System.out.println("Enter salary");
			e.salary=Float.parseFloat(r.readLine());
			addEmployee(e);
			main(args);
			break;
		}
		case 2:
		{
			System.out.println("Enter Employee ID");
			int id=Integer.parseInt(r.readLine());
			deleteEmployee(id);
			main(args);
			break;
		}
		case 3:
		{
			System.out.println("Enter Employee ID");
			int id=Integer.parseInt(r.readLine());
			ShowPaySlip(id);
			main(args);
			break;
		}
		case 4:
		{
			System.out.println("Thank You");
			break;
		}
		}
		

	}

}
