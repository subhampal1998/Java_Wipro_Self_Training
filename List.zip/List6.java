import java.util.*;
class List6
    {
        public static void main(String[] args)
        {
            Vector<String> ll=new Vector<String>();
            ll.add("January");
            ll.add("February");
            ll.add("March");
            ll.add("April");
            ll.add("May");
            ll.add("June");
            ll.add("July");
            ll.add("August");
            ll.add("September");
            ll.add("October");
            ll.add("November");
            ll.add("December");
            System.out.print(ll);
        }
    }