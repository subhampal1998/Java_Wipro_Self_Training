
public class Employee {
	int empId;
	String empName;
	String email;
	String gender;
	float salary;
	void GetEmployeeDetails()
	{
		System.out.println("Employee ID: "+empId);
		System.out.println("Employee Name: "+empName);
		System.out.println("Email: "+email);
		System.out.println("Gender: "+gender);
		System.out.println("Salary: "+salary);
	}
}
