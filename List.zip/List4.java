import java.util.*;
class List4
    {
        public static void main(String[] args)
        {
            ArrayList<Double> al=new ArrayList<Double>();
            al.add(new Double(23.4));
            al.add(new Double(13));
            al.add(12.333);
            al.add(new Double(14));
            System.out.println(al);
        }
    }
            