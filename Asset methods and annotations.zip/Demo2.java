
public class Demo2 {
	boolean palindromeCheck(String a)
	{
		int l=a.length();
		String w="";
		for(int i=l-1;i>=0;i--)
		{
			char b=a.charAt(i);
			w=w+b;
		}
		if(a.equals(w))
			return true;
		return false;
	}
}
