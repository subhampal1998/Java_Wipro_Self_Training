import static org.junit.Assert.*;

import org.junit.Test;
import java.util.ArrayList;
public class EmployeeTest {

	@Test
	public void test() {
		Employee e=new Employee();
		ArrayList<String> employees=new ArrayList<String>(5);
		employees.add("Subham");
		employees.add("Wipro");
		employees.add("Pal");
		assertEquals("FOUND",e.findName(employees,"Subham"));
	}

}
