
public class NegetiveValueException extends Exception {
	public String toString()
	{
		return "NegetiveValueExceptionOccured";
	}
}
