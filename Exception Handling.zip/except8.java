
public class except8 {

	public static void main(String[] args)throws MyException {
		try
		{
			int n=Integer.parseInt(args[0]);
			if(n>=18&&n<=60)
				System.out.println("Proper Age");
			else
				throw new MyException();
		}
		catch(MyException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
