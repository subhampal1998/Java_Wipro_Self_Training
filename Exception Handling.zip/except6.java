import java.io.*;
public class except6 {

	public static void main(String[] args)throws IOException, NegetiveValueException, ValueOutOfRangeException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		String name[]=new String[2];
		int marks[]=new int[6];
		double avg[]=new double[2];
		int sum=0;
		for(int i=0;i<2;i++)
		{
			try 
			{
				System.out.println("Enter Name");
				name[i]=r.readLine();
				System.out.println("Enter Marks");
				for(int j=0;j<3;j++)
				{
					marks[j]=Integer.parseInt(r.readLine());
					if(marks[j]<0)
						throw new NegetiveValueException();
					if(marks[j]>100)
						throw new ValueOutOfRangeException();
					sum=sum+marks[j];
				}
				avg[i]=sum/3.0;
				System.out.println(avg);
				sum=0;
			}
			catch(NumberFormatException e)
			{
				System.out.println(e);
			}
			catch(NegetiveValueException e1)
			{
				System.out.println(e1);
			}
			catch(ValueOutOfRangeException e2)
			{
				System.out.println(e2);
			}
		}

	}

}
