import java.io.*;
public class except2 {

	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of elements in the array");
		int n=Integer.parseInt(r.readLine());
		int arr[]=new int[n];
		System.out.println("Enter elements of the array");
		for(int i=0;i<n;i++)
			arr[i]=Integer.parseInt(r.readLine());
		try
		{
			System.out.println("Enter the index of the array element you want to access");
			int x=Integer.parseInt(r.readLine());
			System.out.println("The array element at index "+x+" = "+arr[x]);
			System.out.println("The array element sucessfully accessed");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
	}

}
