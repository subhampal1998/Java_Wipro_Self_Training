import java.io.*;
public class except1 {

	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		try
		{
			System.out.print("Enter an integer: ");
			int n=Integer.parseInt(r.readLine());
			System.out.println("The square value is: "+ (n*n));
			System.out.print("The work has been done sucessfully");
		}
		catch(NumberFormatException e)
		{
			System.out.print("Entered input is not a valid format for an integer.");
		}
	}

}
