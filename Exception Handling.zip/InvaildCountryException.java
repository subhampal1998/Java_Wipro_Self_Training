
public class InvaildCountryException extends Exception {
	public String toString()
	{
		return "User Outside India cannot be registered";
	}
}
