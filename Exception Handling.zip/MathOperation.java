
public class MathOperation {

	public static void main(String[] args) {
		int arr[]=new int[5];
		int sum=0;
		double avg=0.0;
		try
		{
		for(int i=0;i<5;i++)
			arr[i]=Integer.parseInt(args[i]);
		for(int i=0;i<5;i++)
			sum=sum+arr[i];
		avg=sum/5.0;
		System.out.println("The sum is "+sum);
		System.out.println("The average is "+avg);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}

}
