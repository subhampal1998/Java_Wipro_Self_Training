
public class ValueOutOfRangeException extends Exception {
	public String toString()
	{
		return "ValueOutOfRangeExceptionOccured";
	}
}
