
public class MyException extends Exception {
	public String toString()
	{
		return "Improper Age";
	}
}
