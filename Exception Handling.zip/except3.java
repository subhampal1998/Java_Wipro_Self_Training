import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class except3 {

	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of elements in the array");
		int n=Integer.parseInt(r.readLine());
		int arr[]=new int[n];
		try
		{
		System.out.println("Enter elements of the array");
		for(int i=0;i<n;i++)
			arr[i]=Integer.parseInt(r.readLine());
		System.out.println("Enter the index of the array element you want to access");
			int x=Integer.parseInt(r.readLine());
			System.out.println("The array element at index "+x+" = "+arr[x]);
			System.out.println("The array element sucessfully accessed");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(NumberFormatException e)
		{
			System.out.println(e);
		}
	}

}
