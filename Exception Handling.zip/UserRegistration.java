
public class UserRegistration {
	static void registerUser(String username,String userCountry)throws InvaildCountryException
	{
	if(userCountry.equals("India"))
		System.out.println("User Registration done sucessfully");
	else
		throw new InvaildCountryException();
	}
	public static void main(String[] args) {
		try
		{
			registerUser(args[0],args[1]);
		}
		catch(InvaildCountryException e)
		{
			System.out.println(e);
		}

	}

}
