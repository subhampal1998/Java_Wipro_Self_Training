
public class String7 {

	public static void main(String[] args) {
		String a=new String(args[0]);
		System.out.println(string7(a));

	}
	public static String string7(String a)
	{
		int l=a.length();
		if(a.charAt(0)==a.charAt(l-1)&&a.charAt(0)=='x')
			return a.substring(1,l-1);
		else
			return a;
	}

}
