
public class String8 {

	public static void main(String[] args) {
		String a=new String(args[0]);
		System.out.println(string8(a));

	}
	public static String string8(String a)
	{
		int l=a.length();
		for(int i=0;i<l;i++)
		{
			if(a.charAt(i)=='*')
				return a.substring(0,i);
		}
			return null ;
		
	}
		
}
	