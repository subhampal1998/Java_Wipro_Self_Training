
public class String10 {

	public static void main(String[] args) {
		String a=new String(args[0]);
		int n=Integer.parseInt(args[1]);
		System.out.println(string10(a,n));

	}
	public static String string10(String a,int n)
	{
		int l=a.length();
		String y="";
		String x=a.substring(l-n,l);
		for(int i=1;i<=n;i++)
		y=y+x;
		return y;
		
		

	}

}
