
public class String5 {

	public static void main(String[] args) {
		String a=new String(args[0]);
		System.out.println(string5(a));
	}
public static String string5(String a)
	{
		int l=a.length();
		return a.substring(1,l-1);
	}
}
