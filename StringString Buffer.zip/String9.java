
public class String9 {

	public static void main(String[] args) {
		String a=new String(args[0]);
		String b=new String(args[1]);
		System.out.println(string9(a,b));

	}
	public static String string9(String a, String b)
	{
		int la=a.length();
		int lb=b.length();
		String w="";
		int sm=la<lb?la:lb;
		for(int i=0;i<sm;i++)
		{
			w=w+a.charAt(i);
			w=w+b.charAt(i);
		}
		if(sm-la>0)
			w=w+b.substring(sm,lb);
		else
			w=w+a.substring(sm,la);
		return w;

	}

}
