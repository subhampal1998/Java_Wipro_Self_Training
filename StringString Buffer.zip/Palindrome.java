
public class Palindrome {

	public static void main(String[] args) {
		String s=new String("MADAM");
		String s1=new String();
		int l=s.length();
		for(int i=0;i<l;i++)
		{
			char b=s.charAt(i);
			s1=s1+b;
		}
		if(s.equals(s1))
			System.out.println("Palindrome");
		else
			System.out.println("Not Palindrome");
	}

}
