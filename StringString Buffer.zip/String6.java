
public class String6 {

	public static void main(String[] args) {
		String a=new String(args[0]);
		String b=new String(args[1]);
		System.out.println(string6(a,b));

	}
	public static String string6(String a, String b)
	{
		int la=a.length();
		int lb=b.length();
		if(la>lb)
			return b+a+b;
		else
			return a+b+a;
	}

}


