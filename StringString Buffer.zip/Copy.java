
public class Copy {

	public static void main(String[] args) {
		System.out.println(copy(args[0]));
		

	}
	public static String copy(String a)
	{
		int l=a.length();
		String x=a.substring(0,2);
		String y="";
		for(int i=1;i<=l;i++)
			y=y+x;
		return y;
		
	}

}
