
public class String11 {

	public static void main(String[] args) {
		String a=new String(args[0]);
		String b=new String(args[1]);
		System.out.println(string11(a,b));

	}
	public static String string11(String a,String b)
	{
		int la=a.length();
		int lb=b.length();
		String y="";
		for(;;)
		{
			int n=a.indexOf(b);
			if(n==-1)
				break;
			if(n==0)
				y=y+a.charAt(lb);
			else
			{
				if(n+lb==la)
				{
					y=y+a.charAt(n-1);
					break;
				}
				else
				{
					y=y+a.charAt(n-1);
				    y=y+a.charAt(n+lb);
				}
			}
			a=a.substring(n+lb,la);
			la=a.length();
		}
		return y;

	}

}

