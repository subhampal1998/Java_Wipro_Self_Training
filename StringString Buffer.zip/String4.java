
public class String4 {

	public static void main(String[] args) {
		String s=new String(args[0]);
		
		System.out.println(string4(s));
		}
	public static String string4(String a)
	{
		int l=a.length();
		if(l%2==0)
			return a.substring(0,l/2);
		else
			return null;
	}
}
