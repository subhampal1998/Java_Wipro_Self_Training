import java.io.*;
import java.util.*;
public class EMM implements Serializable {
	
	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		File in=new File("Employee.txt");
		FileReader fr=new FileReader(in); 
		FileWriter wr=new FileWriter(in,true);
		System.out.println("Main Menu");
		System.out.println("1.Add an Employee");
		System.out.println("2.Display All");
		System.out.println("3.Exit");
		int n=Integer.parseInt(r.readLine());
		switch(n)
		{
		case 1:
		{
			System.out.println("Enter Employee ID:");
			String id=r.readLine();
			wr.write("id:"+id+"\n");
			System.out.println("Enter Employee Name:");
			String na=r.readLine();
			wr.write("Name:"+na+"\n");
			System.out.println("Enter Employee Age:");
			String age=r.readLine();
			wr.write("Age:"+age+"\n");
			System.out.println("Enter Employee Salary:");
			String sal=r.readLine();
			wr.write("Salary:"+sal+"\n");
			wr.close();
			main(args);
			break;
		}
		case 2:
		{
			int c;
			while((c=fr.read())!=-1)
			{
				System.out.print((char)c);
			}
			fr.close();
			main(args);
			break;
		}
		case 3:
		{
			System.out.println("Exiting The System");
			
			
		}
		}

	}

}
