import java.util.*;
import java.io.*;
public class Set4 {
	static TreeSet<String> h1=new TreeSet<String>();
	static String saveCountryNames(String CountryName)
	{
		h1.add(CountryName);
		return CountryName;
	}
	static String getCountry(String CountryName)
	{
		Iterator<String> i=h1.iterator();
		while(i.hasNext())
		{
			String x=i.next();
			if(x.equals(CountryName))
				return x;
		}
			return null;
	}
	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("1.Add Country");
		System.out.println("2.Check Country");
		System.out.println("3.Exit");
		int n=Integer.parseInt(r.readLine());
		switch(n)
		{
		case 1:
		{
			System.out.println("Enter Country");
			String c=r.readLine();
			System.out.println(saveCountryNames(c));
			main(args);
			break;
		}
		case 2:
		{
			System.out.println("Enter Country");
			String d=r.readLine();
			System.out.println(getCountry(d));
			main(args);
			break;
		}
		case 3:
		{
			System.out.println("Thank you");
			break;
		}
	}

}
}