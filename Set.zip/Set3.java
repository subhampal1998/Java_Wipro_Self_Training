import java.util.*;
public class Set3 {

	public static void main(String[] args) {
		TreeSet<String> ts=new TreeSet<String>();
		TreeSet<String> st=new TreeSet<String>();
		ts.add("ABCD");
		ts.add("Subham");
		ts.add("Wipro");
		ts.add("Job");
		System.out.println(ts);
		st=(TreeSet<String>)ts.descendingSet();
		System.out.println(st);
		for(Iterator <String>i=ts.iterator();i.hasNext();)
        	System.out.println(i.next());
		Iterator <String>i1=ts.iterator();
		int f=0;
		while(i1.hasNext())
		{
			String x=i1.next();
			if(x.equals(args[0]))
			{
				f=1;
				System.out.println("Found");
			}
				
		}
		if(f==0)
			System.out.println("Not Found");
	}
	}


