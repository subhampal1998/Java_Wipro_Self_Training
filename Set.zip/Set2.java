import java.util.*;
import java.util.Iterator;
class Set2
    {
        public static void main(String[] args)
        {
        	HashSet <String> hs=new HashSet<String>();
            hs.add("Subham Pal");
            hs.add("John Wiliams");
            hs.add("Jessie Mon");
            hs.add("Jon Snow");
            for(Iterator<String> i=hs.iterator();i.hasNext();)
            	System.out.println(i.next());
        }
    }
            