package com.wipro.automobile.ship;

public class compartment {
	int height;
	int width;
	int breadth;
}
