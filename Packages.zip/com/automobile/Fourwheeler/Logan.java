package com.automobile.Fourwheeler;
public class Logan extends com.automobile.Vehicle {
	public String getModelName()
	{
		return "Logan";
	}
	public String getRegistrationNumber()
	{
		return "WB42E3425";
	}
	public String getOwnerName()
	{
		return "Subham Pal";
	}
	public int speed()
	{
		return 56;
	}
	public void gps()
	{
		System.out.println("Control gps device");
	}
}
