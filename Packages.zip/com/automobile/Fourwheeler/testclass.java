package com.automobile.Fourwheeler;

public class testclass {

	public static void main(String[] args) {
		Ford f=new Ford();
		Logan l=new Logan();
		System.out.println(f.getModelName());
		System.out.println(f.getOwnerName());
		System.out.println(f.getRegistrationNumber());
		System.out.println(f.speed());
		f.tempControl();
		System.out.println(l.getModelName());
		System.out.println(l.getOwnerName());
		System.out.println(l.getRegistrationNumber());
		System.out.println(l.speed());
		l.gps();

	}

}
