package com.automobile.Fourwheeler;

public class Ford extends com.automobile.Vehicle {
	public String getModelName()
	{
		return "Ford";
	}
	public String getRegistrationNumber()
	{
		return "WB42R7889";
	}
	public String getOwnerName()
	{
		return "Virat Kohli";
	}
	public int speed()
	{
		return 150;
	}
	public void tempControl()
	{
		System.out.println("Control the air conditioning device");
	}
}
