package com.automobile.twowheeler;
public class Hero extends com.automobile.Vehicle {
	public String getModelName()
	{
		return "Hero";
	}
	public String getRegistrationNumber()
	{
		return "WB42Q3399";
	}
	public String getOwnerName()
	{
		return "Subham Pal";
	}
	public int speed()
	{
		return 45;
	}
	public void radio()
	{
		System.out.println("Control radio of twowheeler");
	}
}
