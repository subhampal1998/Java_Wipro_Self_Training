public class Honda extends com.automobile.Vehicle {
	public String getModelName()
	{
		return "Honda";
	}
	public String getRegistrationNumber()
	{
		return "WB42A3299";
	}
	public String getOwnerName()
	{
		return "Subham Das";
	}
	public int speed()
	{
		return 48;
	}
	public void cdplayer()
	{
		System.out.println("Control cdplayer of car");
	}
}
