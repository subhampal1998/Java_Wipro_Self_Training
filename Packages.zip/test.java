import com.automobile.twowheeler.*;
public class test {

	public static void main(String[] args) {
		Hero hero=new Hero();
		Honda honda=new Honda();
		System.out.println(hero.speed());
		hero.radio();
		System.out.println(honda.speed());
		honda.cdplayer();

	}

}
