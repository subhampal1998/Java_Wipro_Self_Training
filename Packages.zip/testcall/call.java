package testcall;
import test.foundation;
public class call {

	public static void main(String[] args) {
		foundation f=new foundation();
		System.out.println(f.var1);
		System.out.println(f.var2);
		System.out.println(f.var3);
		System.out.println(f.var4);

	}

}
