import org.junit.runner.RunWith;		
import org.junit.runners.Suite;	
@RunWith(Suite.class)
@Suite.SuiteClasses({EmployeeTest.class,Demo1Test.class,Demo2Test.class})
public class AllTests {

}
