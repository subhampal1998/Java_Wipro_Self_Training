import static org.junit.Assert.*;

import org.junit.Test;

public class VideoTest {

	@Test
	public void test() {
		Video v=new Video("Matrix");
		assertEquals("Matrix",v.getName());
		assertEquals(0,v.getRating());
		assertEquals(false,v.getCheckout());
	}

}
