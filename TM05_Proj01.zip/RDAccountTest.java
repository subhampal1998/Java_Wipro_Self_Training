import static org.junit.Assert.*;

import org.junit.Test;

public class RDAccountTest {

	@Test(timeout=900)
	public void test() {
		RDAccount rd=new RDAccount();
		assertEquals(0.0,0.0,rd.calculateInterest());
	}

}
