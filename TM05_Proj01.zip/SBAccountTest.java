import static org.junit.Assert.*;

import org.junit.Test;

public class SBAccountTest {

	@Test
	public void test() {
		SBAccount sb=new SBAccount();
		assertEquals(0.0,0.0,sb.calculateInterest());
	}

}
