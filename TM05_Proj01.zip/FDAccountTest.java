import static org.junit.Assert.*;

import org.junit.Test;

public class FDAccountTest {

	@Test(timeout=1000)
	public void test() {
		FDAccount fd=new FDAccount();
		assertEquals(0.0,0.0,fd.calculateInterest());
	}

}
