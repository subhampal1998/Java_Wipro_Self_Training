
public class employee implements Cloneable {
	String ID;
	double salary;
	employee cloneTest()
	{
		try
		{
			return (employee)super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			System.out.println(e);
			return this;
		}
	}
	}
