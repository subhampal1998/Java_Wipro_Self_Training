import java.io.*;
public class wrap3 {

	public static void main(String[] args)throws IOException {
		BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter number between 1 to 255");
		int n=Integer.parseInt(r.readLine());
		String bin=Integer.toBinaryString(n);
		int binInt=Integer.parseInt(bin);
		bin=String.format("%08d", binInt);
		System.out.println(bin);

	}

}
