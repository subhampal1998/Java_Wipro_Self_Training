
public class testemployee {

	public static void main(String[] args) {
		employee e=new employee();
		e.ID="SXCDR23";
		e.salary=34567.65;
		employee e1;
		e1=e.cloneTest();
		System.out.println("Object e ID: "+e.ID);
		System.out.println("Object e salary: "+e.salary);
		System.out.println("Object e1 ID: "+e1.ID);
		System.out.println("Object e1 salary: "+e.salary);
		e1.ID="DSCGS22";
		e1.salary=45682.34;
		System.out.println("Object e ID: "+e.ID);
		System.out.println("Object e salary: "+e.salary);
		System.out.println("Object e1 ID: "+e1.ID);
		System.out.println("Object e1 salary: "+e1.salary);

	}

}
