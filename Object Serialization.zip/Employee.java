import java.io.Serializable;
import java.util.*;
public class Employee implements Serializable {
	String name;
	Date dateOfBirth;
	String department;
	String designation;
	double Salary;
	public Employee(String name,Date dateOfBirth,String department,String designation,double Salary)
	{
		this.name=name;
		this.dateOfBirth=dateOfBirth;
		this.department=department;
		this.designation=designation;
		this.Salary=Salary;
	}
	String Name()
	{
		return name;
	}
	Date dob()
	{
		return dateOfBirth;
	}
	String dept()
	{
		return department;
	}
	String des()
	{
		return designation;
	}
	double salary()
	{
		return Salary;
	}
}
