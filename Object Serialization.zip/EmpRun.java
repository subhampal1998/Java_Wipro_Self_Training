import java.util.*;
import java.io.*;
import java.text.*;
public class EmpRun  {

	public static void main(String[] args)throws Exception {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
		Employee e=new Employee("Subham Pal",sdf.parse("1998-02-11"),"IT","Project Engineer",34000.21);
		try
		{
			FileOutputStream fos=new FileOutputStream("data");
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			oos.writeObject(e);
			oos.flush();
			oos.close();
		}
		catch (Exception e1)
		{
			System.out.println(e1);
		}
		try
		{
			Employee E;
			FileInputStream fis=new FileInputStream("data");
			ObjectInputStream ois=new ObjectInputStream(fis);
			E=(Employee)ois.readObject();
			ois.close();
			System.out.println("Name: "+E.name);
			System.out.println("Date Of Birth: "+E.dateOfBirth);
			System.out.println("Department: "+E.department);
			System.out.println("Designation: "+E.designation);
			System.out.println("Salary: "+E.Salary);
		}
		catch (Exception x)
		{
			System.out.println(x);
		}
	}
}


