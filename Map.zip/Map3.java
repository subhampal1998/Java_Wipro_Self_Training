import java.util.*;
public class Map3 {

	public static void main(String[] args) {
		Properties p=new Properties();
		p.put("West Bengal", "Kolkata");
		p.put("Karnataka", "Bangalore");
		p.put("Maharastra","Mumbai");
		String str;
		Set set=p.keySet();
		Iterator i=set.iterator();
		while(i.hasNext())
		{
			str=(String)i.next();
			System.out.println(str+" "+p.getProperty(str));
		}
	}
}

	


