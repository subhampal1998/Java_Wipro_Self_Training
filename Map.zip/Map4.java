import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
public class Map4 {

	public static void main(String[] args) {
		HashMap<String,Integer> ContactList=new HashMap<String,Integer>();
		ContactList.put("SubhamPal", 877253778);
		ContactList.put("ZeeshanKazi", 52387628);
		ContactList.put("JohnSnow",567932993);
		Set set=ContactList.entrySet();
		Iterator i=set.iterator();
		int k=0;
		int v=0;
		while(i.hasNext())
		{
			Map.Entry<String,Integer> me=(Map.Entry<String,Integer>)i.next();
			if(me.getKey().equals(args[0]))
			{
				k=1;
				System.out.println(args[0]+" key exists.");
			}
			int n=Integer.parseInt(args[1]);
			if(me.getValue()==n)
			{
				v=1;
				System.out.println(args[1]+" value exists.");
			}
		}
		if(k==0)
			System.out.println("Key not found");
		if(v==0)
			System.out.println("Value not found");
	}
}
	
	


