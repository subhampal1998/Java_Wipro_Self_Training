import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class Map1 {
	static HashMap<String,String> M1=new HashMap<String,String>();
	static HashMap<String,String> saveCountryCapital(String CountryName, String capital )
	{
		M1.put(CountryName, capital);
		return M1;
	}
	static String getCapital(String CountryName)
	{
		Set set=M1.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String> me=(Map.Entry<String,String>)i.next();
			if(me.getKey().equals(CountryName))
				return(String)me.getValue();
		}
			return "Not Found";
	}
	static String getCountry(String capitalName)
	{
		Set set=M1.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String> me=(Map.Entry<String,String>)i.next();
			if(me.getValue().equals(capitalName))
				return(String)me.getKey();
		}
			return "Not Found";
	}
	static HashMap<String,String> interchange()
	{
		HashMap<String,String> M2=new HashMap<String,String>();
		Set set=M1.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String> me=(Map.Entry<String,String>)i.next();
			M2.put(me.getValue(), me.getKey());
		}
		return M2;
	}
	static ArrayList<String> countryarray()
	{
		ArrayList<String> al=new ArrayList<String>();
		Set set=M1.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String> me=(Map.Entry<String,String>)i.next();
			al.add(me.getKey());
		}
		return al;
	}
	public static void main(String[] args)throws IOException{
		  BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
	        System.out.println("MAIN MENU");
	        System.out.println("-----------");
	        System.out.println("1.Add Country & Capital");
	        System.out.println("2.Get Capital");
	        System.out.println("3.Get Country");
	        System.out.println("4.Interchange Key & Value");
	        System.out.println("5.Create Country ArrayList");
	        System.out.println("6.Exit");
	        System.out.println("Enter your option (1....6):");
	        int n=Integer.parseInt(r.readLine());
	        switch(n)
	        {
	        case 1:
	        {
	        	System.out.println("Enter Country & Capital");
	        	String con=r.readLine();
	        	String cap=r.readLine();
	        	System.out.println(saveCountryCapital(con,cap));
	        	main(args);
	        	break;
	        }
	        case 2:
	        {
	        	System.out.println("Enter Country");
	        	String con1=r.readLine();
	        	System.out.println(getCapital(con1));
	        	main(args);
	        	break;
	        }
	        case 3:
	        {
	        	System.out.println("Enter Capital");
	        	String cap1=r.readLine();
	        	System.out.println(getCountry(cap1));
	        	main(args);
	        	break;
	        }
	        case 4:
	        {
	        	System.out.println(interchange());
	        	main(args);
	        	break;
	        }
	        case 5:
	        {
	        	System.out.println(countryarray());
	        	main(args);
	        	break;
	        }
	        case 6:
	        {
	        	System.out.println("Thank you");
	        	break;
	        }
	        }

	}

}
