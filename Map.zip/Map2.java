import java.util.*;
public class Map2 {

	public static void main(String[] args) {
		HashMap<String,String> M1=new HashMap<String,String>();
		M1.put("Subham", "Pal");
		M1.put("Zeeshan", "Kazi");
		M1.put("John","Snow");
		Set set=M1.entrySet();
		Iterator i=set.iterator();
		int k=0;
		int v=0;
		while(i.hasNext())
		{
			Map.Entry<String,String> me=(Map.Entry<String,String>)i.next();
			if(me.getKey().equals(args[0]))
			{
				k=1;
				System.out.println(args[0]+" key exists.");
			}
			if(me.getValue().equals(args[1]))
			{
				v=1;
				System.out.println(args[1]+" value exists.");
			}
		}
		if(k==0)
			System.out.println("Key not found");
		if(v==0)
			System.out.println("Value not found");
	}
}
	
	


